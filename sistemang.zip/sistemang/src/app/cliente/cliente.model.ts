export class Cliente {

    id: Number;
    nome: String;
    dataNascimento:any;

}